function AddPoint(){
    this.x;
    this.y;

    this.pickLocalation = function (){
        this.x = (Math.floor(Math.random() * rows - 1) + 1) * scale;
        this.y = (Math.floor(Math.random() * columns - 1) + 1) * scale;
    }

    this.draw = function (){
        let img = document.getElementById("halt");
        ctx.fillStyle = '#ff556f';
        ctx.drawImage(img,this.x,this.y, scale, scale);

    }
}