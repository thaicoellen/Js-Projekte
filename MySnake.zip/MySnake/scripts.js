const canvas = document.querySelector('.canvas');
const ctx = canvas.getContext('2d');
const scale = 10;
const rows = canvas.height / scale;
const columns = canvas.width / scale;
const startBtn = document.querySelector('.start')

var snake;

function startGame() {
    currentSnake.forEach(index => squares[index].classList.remove('snake'))
    squares[addPointIndex].classList.remove('addPoint')
    clearInterval(interval)
    score = 0
    randomaddPoint()
    direction = 1
    scoreDisplay.innerText = score
    intervalTime = 1000
    currentSnake = [2, 1, 0]
    currentIndex = 0
    currentSnake.forEach(index => squares[index].classList.add('snake'))
    interval = setInterval(moveOutcomes, intervalTime)
}

function setup(){
    snake = new Snake();
    addPoint = new AddPoint();
    addPoint.pickLocalation();

    window.setInterval(() => {
       ctx.clearRect(0, 0, canvas.width, canvas.height);
       addPoint.draw();
       snake.update();
       snake.draw();

       if (snake.grow(addPoint)){
           addPoint.pickLocalation();
       }

       snake.checkCollision();
       document.querySelector('.score')
       .innerText = snake.total;
    }, 250);
};

setup();



window.addEventListener('keydown', ((evt) => {
    const direction = evt.key.replace('Arrow', '');
    snake.changeDirection(direction);
}));